#include <stdio.h>

void koboImaginaryChess(int i, int j, int size, int *chessBoard) {
    int geser[8][2] = {{-2, -1}, {-1, -2}, {1, -2}, {2, -1},
                       {2, 1}, {1, 2}, {-1, 2}, {-2, 1}};

    for (int k = 0; k < 8; k++) {
        int new_i = i + geser[k][0];
        int new_j = j + geser[k][1];

        if (new_i >= 0 && new_i < size && new_j >= 0 && new_j < size) {
            chessBoard[new_i * size + new_j] = 1;
        }
    }
}

int main() {
    int y, z;
    const int size = 8; 
    int papan_catur[size][size];

    for (y = 0; y < size; y++) {
        for (z = 0; z < size; z++) {
            papan_catur[y][z] = 0;
            printf("%d ", papan_catur[y][z]);
        }
        printf("\n");
    }
    scanf("%d %d", &y, &z);

    koboImaginaryChess(y, z, size, (int *)papan_catur);
    printf("\n");

    for (y = 0; y < size; y++) {
        for (z = 0; z < size; z++) {
            printf("%d ", papan_catur[y][z]);
        }
        printf("\n");
    }

    return 0;
}
